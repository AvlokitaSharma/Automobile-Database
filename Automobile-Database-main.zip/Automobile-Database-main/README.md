# Automobile-Database

Automobile Database

•	Developed an application for automobile domain to store and look up car model details using Java, mySQL, and Java Persistence API.

•	Designed the entity model using POJO (Plain Old Java Object) and generated the database using JPA.

•	Used a parameterized query to eliminate SQL injection attacks.
